function showNewsletter() {
  const newsletter = document.getElementById("newsletter");
  if (newsletter.style.display === "none") {
    newsletter.style.display = "block";
  } else {
    newsletter.style.display = "none";
  }
}

const newsletterForm = document.getElementById("newsletterForm");
newsletterForm.addEventListener("submit", function(event) {
  event.preventDefault(); // Prevent default form submission behavior
  const email = document.getElementById("email").value;
  // Simulate sending email for newsletter subscription (replace with actual functionality)
  alert("Thank you for subscribing to the Greener Campus newsletter! You will now receive updates via email: " + email);
  // Clear the email field after submission
  document.getElementById("email").value = "";
});
